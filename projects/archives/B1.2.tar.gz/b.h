#ifndef B_H
#define B_H
#include <string>

void hello_b(std::string caller);

#endif