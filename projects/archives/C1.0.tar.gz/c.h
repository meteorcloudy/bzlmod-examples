#ifndef C_H
#define C_H
#include <string>

void hello_c(std::string caller);

#endif