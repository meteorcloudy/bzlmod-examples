#ifndef A_H
#define A_H
#include <string>

void hello_a(std::string caller);

#endif